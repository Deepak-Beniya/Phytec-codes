int breakfast(int);
int dinner(int);
int lunch(int);
int quant(int,int);