#include<stdio.h>

int quant(int a,int num){

    

    switch(a){

        case 1:{      switch(num){

                    case 1:
                            printf("Total Amount is  10 Rupees \n");
                            printf("Enjoy your Breakfast :) \n");
                            break; 

                    case 2:
                            printf("Total Amount is  20 Rupees \n");
                            printf("Enjoy your Breakfast :) \n");
                            break; 

                    case 3:
                            printf("Total Amount is  30 Rupees \n");
                            printf("Enjoy your Breakfast :) \n");
                            break;

                    case 4:
                            printf("Total Amount is  40 Rupees \n");
                            printf("Enjoy your Breakfast :) \n");
                            break;

                    case 5:
                            printf("Total Amount is  50 Rupees \n");
                            printf("Enjoy your Breakfast :) \n");
                            break;

                    default : 
                            printf("Enter the correct number :");
                             break;
         
                    }
                
            }break;

        case 2: {    switch(num){

                    case 1:
                            printf("Total Amount is  100 Rupees \n");
                            printf("Enjoy your Lunch :) \n");
                            break; 

                    case 2:
                            printf("Total Amount is  200 Rupees \n");
                            printf("Enjoy your Lunch :) \n");
                            break; 

                    case 3:
                            printf("Total Amount is  300 Rupees \n");
                            printf("Enjoy your Lunch :) \n");
                            break;

                    case 4:
                            printf("Total Amount is  400 Rupees \n");
                            printf("Enjoy your Lunch :) \n");
                            break;

                    case 5:
                            printf("Total Amount is  500 Rupees \n");
                            printf("Enjoy your Lunch :) \n");
                            break;

                    default : 
                            printf("Enter the correct number :");
                             break;
           
                    }

                }break;

        
        case 3: {    switch(num){

                    case 1:
                            printf("Total Amount is  100 Rupees \n");
                            printf("Enjoy your NAAN + CHICKEN KASA :) \n");
                            break; 

                    case 2:
                            printf("Total Amount is  200 Rupees \n");
                            printf("Enjoy your NAAN + MUTTON KASA :) \n");
                            break; 

                    case 3:
                            printf("Total Amount is  300 Rupees \n");
                            printf("Enjoy your ROTI + CHICKEN TANDORI :) \n");
                            break;

                    case 4:
                            printf("Total Amount is  400 Rupees \n");
                            printf("Enjoy your NON-VEG BIRIYANI :) \n");
                            break;

                    case 5:
                            printf("Total Amount is  500 Rupees \n");
                            printf("Enjoy your CHICKEN BIRIYANI :) \n");
                            break;

                    default : 
                            printf("Enter the correct number :");
                             break;

                              
                    }

                }break;

    }




    

 
return 0;

    }
