#include<stdio.h>
int eng(int e){
    
    printf("Enter the mark of English:\n");
    scanf("%d",&e);

    return e;

}