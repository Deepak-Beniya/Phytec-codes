#include<stdio.h>
int bio(int b){
    
    printf("Enter the mark of Biology:\n");
    scanf("%d",&b);
    return b;

}
