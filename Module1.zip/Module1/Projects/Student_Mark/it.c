#include<stdio.h>
int it(int i){
    
    printf("Enter the mark of IT:\n");
    scanf("%d",&i);
    
    return i;
}