#include<stdio.h>
int phy(int p){
    
    printf("Enter the mark of Physics:\n");
    scanf("%d",&p);
    return p;

}