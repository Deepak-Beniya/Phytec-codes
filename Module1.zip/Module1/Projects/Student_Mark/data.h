int phy(int);
int che(int);
int bio(int);
int it(int);
int eng(int);
int math(int);
int result(int,int,int,int,int,int,int,char[]);