#include<stdio.h>
int che(int c){
    
    printf("Enter the mark of Chemistry:\n");
    scanf("%d",&c);

    return c;
}