#include<stdio.h>
int math(int m){
    
    printf("Enter the mark of Maths:\n");
    scanf("%d",&m);
    return m;

}