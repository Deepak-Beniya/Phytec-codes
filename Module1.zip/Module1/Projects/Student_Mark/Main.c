#include<stdio.h>
#include<string.h>
#include"data.h"
char name[20];
int main(){

int p,c,b,i,e,m,reg;

printf("Enter the Name of the student:\n");
scanf("%s",name);
printf("Enter the regestration number:\n");
scanf("%d",&reg);

result(phy(p),che(c),bio(b),it(i),eng(e),math(m),reg,name);





    

}
