int temp(float*);
int data();
