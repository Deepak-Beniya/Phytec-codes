#include<stdio.h>
#include"myheader.h"





int main(){
    
    
    data();
    
    

    
    return 0;
}




