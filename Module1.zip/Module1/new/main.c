#include"myheader.h"
int main(){

    display("Print a character : %c \n",'D');
    display("Print a string : %s \n","Deepak");
	display("Print a integer : %d \n",25);
	display("Print a zero integer  : %d \n",0);
	display("Print an hex: %x \n",10);
	display("Print a zero hex integer : %x \n",0);

	return 0;
}
