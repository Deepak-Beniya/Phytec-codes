int main(){
// 	void *pointer_to_main = (void *) main;

	

// 	display("Print a character : %c \n",'D');
//     display("Print a string : %s \n","Deepak");
// 	display("Print a integer : %d \n",25);
// 	display("Print a zero integer  : %d \n",0);
// 	display("Print an hex: %x \n",10);
// 	display("Print a zero hex integer : %x \n",0);
// 	display("Print a pointer : %p \n",pointer_to_main);

// 	__uint64_t n = (__uint64_t) -1;
// 	display("Largest 64bit: %lld, %x \n", n,n);

// 	return 0;
// }