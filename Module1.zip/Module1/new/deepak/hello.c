#include<myheader.h>

int main()
{
	display("Hii i am deepak");
}
