/*E13_8*/
#include<stdio.h>
#define . ;
int main(void)
{
	printf("If the lift to success is broken, ").
	printf("Try the stairs.").
	return 0;
}

	
