/*E31_1*/
#define MAX 5;
#include<stdio.h>
int main(void)
{
	printf(" %d ",MAX);
	return 0;
}