/*E13_9*/
#include<stdio.h>
#define CUBE(x) (x*x*x)
int main(void)
{
	printf("%d\n",CUBE(1+2));
	return 0;
}
