/*E10.28*/
#include<stdio.h>
int main(void)
{
	char *ptr;
	ptr = "Every saint has a past,\
            Every sinner has a future.\n";
	printf("Giving " "is " "living.""\n");
	printf(ptr);
	return 0;
}