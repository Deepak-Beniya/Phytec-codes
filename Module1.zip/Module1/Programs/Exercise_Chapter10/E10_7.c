/*E10.7*/
#include<stdio.h>
int main(void)
{
	char str[] ={70,97,105,116,104,0}; 
	printf("%s\n",str);
	return 0;
}
