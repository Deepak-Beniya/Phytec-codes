/*E8.5*/
#include<stdio.h>
int main(void)
{
	int x[10],y[3][4],z[2][3][5];
	printf("%u\t%u\t%u\n",sizeof(x),sizeof(y),sizeof(z));
	return 0;
}