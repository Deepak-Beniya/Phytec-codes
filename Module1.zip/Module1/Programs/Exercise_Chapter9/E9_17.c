/*E9.17*/                                                                              
#include<stdio.h>
int main(void)
{
	int arr[6]={1,2,3,4,5,6};
	int *p=arr;
	printf("Size of p=%u,Size of arr=%u\n",sizeof(p),sizeof(arr));
	return 0;
}
                                                                               
